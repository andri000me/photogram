<?php 
header('Location:page/dashboard.php');
 ?>