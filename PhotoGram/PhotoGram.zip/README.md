# belajarauth
belajar auth

<b>Bismillahirahmanirahim</b>

cara menjalankan: 
1. download atau clone 
  <a href="git clone https://github.com/yudono/belajarauth">git clone https://github.com/yudono/belajarauth</a>
2. taroh di xampp / wamp / laragon , atau di jalankan di terminal, caranya
  buka terminal di folder ketikan <b>php -S 127.0.0.1</b>
3. nyalakan database server mysql biasanya sudah nyatu dalam web server xampp/ wamp/ laragon
4. jalankan

kalo ada yang gak tau nanya

belajar apa saja ?
1. authentication , seperti login logout register
2. cookie session
3. mysqli seperti "new mysqli()"
4. password hashing
5. sabar :v

